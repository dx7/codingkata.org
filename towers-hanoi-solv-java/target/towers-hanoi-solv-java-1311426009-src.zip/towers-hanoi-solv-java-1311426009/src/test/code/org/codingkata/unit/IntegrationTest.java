package org.codingkata.unit;

import org.codingkata.test.CommonIntegrationTest;

/*
 * Please DO NOT RENAME OR MODIFY this file.
 * If you want to do write tests for your own, simply create a separate file.
 */
public class IntegrationTest
        extends CommonIntegrationTest {

    // THIS STAYS EMPTY
}
